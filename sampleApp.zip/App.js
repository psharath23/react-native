/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import * as RNFS from 'react-native-fs';
import Async from 'react-promise'
import _ from 'lodash'
import {
  Platform,
  StyleSheet,
  Text,
  View,
  FlatList,
  ToolbarAndroid,
  TouchableOpacity,
  TouchableHighlight,
  BackHandler,
  Modal,
  Image,
  Alert
} from 'react-native';
import ListMenu from './components/listMenu'
import { validStyles } from './validstyleprops'
const instructions = Platform.select({
  ios: 'Press Cmd+R to reload,\n' +
    'Cmd+D or shake for dev menu',
  android: 'Double tap R on your keyboard to reload,\n' +
    'Shake or press menu button for dev menu',
});

export default class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      pathStack: [RNFS.ExternalStorageDirectoryPath],
      longPressOption: '',
      longPressed: '',
      source: '',
      destination: ''
    }
    BackHandler.addEventListener('hardwareBackPress', () => {
      console.log('back clicked')
      this.back();
      if (this.state.pathStack.length === 1) {
        BackHandler.exitApp();
      } else {
        return true;
      }
    })
  }
  data = [];
  getFileSystem = () => {
    console.log('current--->', _.last(this.state.pathStack));
    return RNFS.readDir(_.last(this.state.pathStack))
      .then((result) => {
        return Promise.all(result);
      });
  }
  onPress = (selected) => {
    if (selected.isDirectory()) {
      let _pathStack = this.state.pathStack
      let _destination = '';
      _pathStack.push(selected.path);
      if (this.state.source !== '') {
        _destination = _.last(_pathStack);
      }
      this.setState({
        pathStack: _pathStack,
        destination: _destination
      });
    }
  }
  folderOptions = () => {
    return <FlatList
      style={styles.longPressMenu}

      keyExtractor={(item) => item}
      renderItem={(item) => <Text style={styles.longPressMenuItem}>item</Text>}
    />
  }
  longPressData = {
    data: ['copy', 'delete', 'move'],
    style: { list: styles.longPressMenu, listItem: styles.longPressMenuItem },
    onPress: (option) => this.onOptionSelected(option)
  }
  onLongPress = (selected) => {
    this.setState({
      longPressed: selected.path
    })
  }
  onOptionSelected = (option) => {
    console.log('option', option)
    let _destination;
    switch (option) {
      case 'copy':
        _destination = (_.filter(_.last(this.state.pathStack).split('/'), (path) => {
          return path !== this.state.longPressed
        })).join('/');
        this.setState({ longPressOption: option, source: this.state.longPressed, longPressed: '', destination: _destination });
        break;
      case 'move':
        _destination = (_.filter(_.last(this.state.pathStack).split('/'), (path) => {
          return path !== this.state.longPressed
        })).join('/');
        this.setState({ longPressOption: option, source: this.state.longPressed, longPressed: '' });
        break;
      case 'delete':
        _destination = (_.filter(_.last(this.state.pathStack).split('/'), (path) => {
          return path !== this.state.longPressed
        })).join('/')
        this.setState({ longPressOption: option, source: this.state.longPressed, longPressed: '', destination: _destination }, () => {
          Alert.alert(
            `Are you sure you want to Delete ${_.last(this.state.source.split('/'))}`,
            '(This cannot be Undone)',
            [{ text: 'OK', onPress: () => this.delete() }, { text: 'Cancel', onPress: () => this.cancelOperation() }]
          )
        });
    }
  }
  copy = () => {
    console.log('s', this.state.source, 'd', decodeURIComponent(this.state.destination + '/'))
    RNFS.copyFile(this.state.source, decodeURIComponent(this.state.destination + '/'))
      .then((copy) => {
        Alert.alert(
          'Success',
          `${_.last(this.state.source.split('/'))} copied to ${this.state.destination}/ successfully`
          [{ text: 'Ok', onPress: () => this.cancelOperation() }]
        )
      })
      .catch((err) => {
        console.log('error', err)
        Alert.alert(
          'Failed',
          `Unable to copy ${_.last(this.state.source.split('/'))} to ${this.state.destination}`,
          [{ text: 'Ok', onPress: () => this.cancelOperation() }]
        )
      })
  }
  move = () => {
    RNFS.moveFile(this.state.source, this.state.destination + '/')
      .then((copy) => {
        Alert.alert(
          'Success',
          `${_.last(this.state.source.split('/'))} moved to ${this.state.destination}/ successfully`
          [{ text: 'Ok', onPress: () => this.cancelOperation() }]
        )
      })
      .catch((err) => {
        Alert.alert(
          'Failed',
          `Unable to move ${_.last(this.state.source.split('/'))} to ${this.state.destination}`,
          [{ text: 'Ok', onPress: () => this.cancelOperation() }]
        )
      })
  }
  delete = () => {
    RNFS.unlink(this.state.source)
      .then((res) => {
        Alert.alert(
          'Success',
          `${this.state.source} deleted`,
          [{ text: 'Ok', onPress: () => this.cancelOperation() }]
        );
      })
      .catch((err) => {
        Alert.alert(
          'Failed',
          `Unable to delete ${_.last(this.state.source.split('/'))}`
          [{ text: 'Ok', onPress: () => this.cancelOperation() }]
        )
      })
  }
  cancelOperation = () => {
    console.log('cancel op')
    this.setState({
      longPressOption: '',
      longPressed: '',
      source: '',
      destination: ''
    })
  }
  _keyExtractor = (item, index) => item.path;
  _renderItem = ({ item }) => (
    <TouchableOpacity onLongPress={this.onLongPress.bind(this, item)} onPress={this.onPress.bind(this, item)}>
      {
        item.isDirectory()
          ?
          <View style={[styles.listItem, styles.directory]}>
            <Image
              style={styles.dirImage}
              source={require('./res/inAppImages/folder.png')}
            />
            <Text style={[styles.directoryText]}>{_.last(item.path.split('/')) + '/'}</Text>
          </View>
          :
          <View style={[styles.listItem, styles.file]}>
            <Image
              style={styles.fileImage}
              source={require('./res/inAppImages/file.png')}
            />
            <Text style={[styles.fileText]}>{_.last(item.path.split('/'))}</Text>
          </View>
      }
      {
        this.state.longPressed === item.path && <ListMenu  {...this.longPressData} />
      }
    </TouchableOpacity >
  )
  back = () => {
    let _pathStack = this.state.pathStack
    if (_pathStack.length !== 1) {
      _pathStack.pop();
    }
    this.setState({
      pathStack: _pathStack
    })

  }
  _toolbarActions = () => [
    { title: 'back', icon: require('./res/toolbar/back.png'), show: 'always' },
    { title: 'menu', icon: require('./res/toolbar/menu.png'), show: 'always' }
  ];
  _onActionSelected = (position) => {
    switch (position) {
      case 0: this.back();
        break;
    }
  }
  renderLongPressInfo = () => {
    console.log('s', this.state.source, 'd', this.state.destination)
    if (this.state.longPressOption) {
      return (
        <View style={styles.longPressActionInfo}>
          <Text style={styles.operationText}>{this.state.longPressOption} :
          </Text>
          <Text style={styles.pathText}>{_.last(this.state.source.split('/'))}</Text>
          <Text style={styles.operationText}>{this.state.longPressOption === 'delete' ? 'from' : 'to'} :
          </Text><Text style={styles.pathText}>{this.state.destination}</Text>
          <Text style={styles.cancelOperation} onPress={this.cancelOperation}>Cancel</Text>
          <Text style={styles.proceedOperation} onPress={this.state.longPressOption === 'copy' ? this.copy : this.move}>{this.state.longPressOption === 'copy' ? 'copy' : 'move'}</Text>
        </View>
      );
    }
  }
  render() {
    return (
      <View style={styles.container}>
        <View>
          <ToolbarAndroid style={styles.toolbar}
            title='File Manager'
            actions={this._toolbarActions()}
            onActionSelected={this._onActionSelected}
          />
        </View>
        {this.renderLongPressInfo()}
        <View><Async
          promise={this.getFileSystem()}
          then={
            (fileSystem) => {
              return <FlatList
                style={{ zIndex: 1 }}
                data={fileSystem}
                extraData={this.state}
                keyExtractor={this._keyExtractor}
                renderItem={this._renderItem}
              />
            }
          } />
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // justifyContent: 'center',
    // alignItems: 'center',
    backgroundColor: '#303a4c',
  },
  listItem: {
    flexDirection: 'row',
    height: 50,
    borderStyle: 'solid',
    borderColor: 'black',
    borderRadius: 5,
    margin: 2,
  },
  toolbar: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 50,
    backgroundColor: '#a9c1e8'
  },
  directoryText: {
    paddingLeft: 20,
    color: '#ffffff',
    textAlign: 'center',
    fontStyle: 'italic'
  },
  fileText: {
    paddingLeft: 20,
    color: '#ffffff',
    textAlign: 'center',
    fontWeight: 'bold'
  },
  directory: {
    backgroundColor: '#124599'
  },
  file: {
    backgroundColor: '#124599'
  },
  dirImage: {
    paddingLeft: 20,
    height: 40,
    width: 40
  },
  fileImage: {
    paddingLeft: 20,
    height: 40,
    width: 40
  },
  longPressMenu: {

  },
  longPressMenuItem: {
    padding: 5,
    backgroundColor: '#ffffff',
    color: '#020202',
    textAlign: 'center'
  },
  longPressActionInfo: {
    // height: 50,
    opacity: 20,
  },
  pathText: {
    color: '#f4bc42',
    fontWeight: 'bold'
  },
  cancelOperation: {
    color: '#d60000',
    fontWeight: 'bold'
  },
  proceedOperation: {
    color: '#0c872a',
    fontWeight: 'bold'
  },
  operationText: {
    color: '#ffffff',
    fontWeight: 'bold'
  }
});
